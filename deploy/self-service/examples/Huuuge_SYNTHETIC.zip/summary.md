# 采集包统计

证据类型：synthetic。

捕获 2；解码成功 2；失败 0。

完整性：finalized。共 1 个片段；以 manifest 中的缺口为准。

包内覆盖：SlotsGameServer.Spin。
